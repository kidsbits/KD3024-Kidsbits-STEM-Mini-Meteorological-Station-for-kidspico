'''
 * Filename    : Rain detection
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM,ADC  # Import ADC module
import time

# Configure ADC, range of 0-3.3V
# define io26,io27,io28,io29 to ADC channel 0,1,2,3
Water = ADC(28)  #Water = ADC(2)
conversion_fator = 3.3 / 65535  #Voltage value of a single scale

buzzer = PWM(Pin(3))
buzzer.freq(800)

# read the analog value every 0.1s, and convert it to voltage output
while True:
    Water_value = Water.read_u16()
    voltage = Water_value * conversion_fator
    print('ADC Value:',Water_value,'   Voltage:',voltage,'V')
    time.sleep(0.1)
    if voltage > 1:
        buzzer.duty_u16(5000)
    else:
        buzzer.duty_u16(0)