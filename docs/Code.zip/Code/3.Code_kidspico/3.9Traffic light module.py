'''
 * Filename    : Traffic light module
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
 
red = Pin(13, Pin.OUT)
yellow = Pin(14, Pin.OUT)
green = Pin(15, Pin.OUT)

while True:
    #Red led lights up for 5s
    red.on()      #Red LED light
    time.sleep(5) #dalye 1s
    red.off()     #Red LED off
    
    #Yellow lef blinks for 3 times
    for i in range(3):
        yellow.on()
        time.sleep(0.5)
        yellow.off()
        time.sleep(0.5)
    
    #Green led lights up for 5s
    green.on()
    time.sleep(5)
    green.off()