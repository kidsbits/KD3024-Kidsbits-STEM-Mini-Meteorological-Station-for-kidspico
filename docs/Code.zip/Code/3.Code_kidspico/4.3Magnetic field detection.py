'''
 * Filename    : Magnetic field detection
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

hall = Pin(8, Pin.IN)
led = Pin(11, Pin.OUT)
while True:
    value = hall.value()
    print(value, end=' ')
    if value == 0:
        led.on()
        print("A magnetic field")
    else:
        led.off()
        print("There is no magnetic field")
    time.sleep(0.1)