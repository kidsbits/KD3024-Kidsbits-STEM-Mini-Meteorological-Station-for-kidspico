'''
 * Filename    : Steam sensor
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC  # 导入ADC模块
import time

# Configure ADC, range 0-3.3V
# define pins io26,io27,io28,io29 to ADC channel 0,1,2,3
Water = ADC(28)  #Photores = ADC(2)
conversion_fator = 3.3 / 65535  #Voltage value of a single scale

# read the analog value every 0.1 seconds and convert it into voltage output
while True:
    Water_value = Water.read_u16()
    voltage = Water_value * conversion_fator
    print('ADC Value:',Water_value,'   Voltage:',voltage,'V')
    time.sleep(0.1)