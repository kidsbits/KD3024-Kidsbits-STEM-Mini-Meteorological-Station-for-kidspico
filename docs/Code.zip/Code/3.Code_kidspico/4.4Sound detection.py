'''
 * Filename    : Sound detection
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC,Pin
import time

# Configure ADC, range of 0-3.3V
# Define io26,io27,io28,io29 to ADC channel 0,1,2,3
MicroPhone = machine.ADC(27)  #MicroPhone = ADC(1)

led = Pin(11, Pin.OUT)
while True:
    Micro_value = MicroPhone.read_u16()
    print(Micro_value)
    time.sleep(0.1)
    if Micro_value > 10000:
        led.on()
    else:
        led.off()