'''
 * Filename    : Air pressure detection
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
from LPS331AP import lps331ap

scl = Pin(5) 
sda = Pin(4)
bus = 0
pressure_temp = lps331ap(bus, scl, sda)

red = Pin(13, Pin.OUT)
yellow = Pin(14, Pin.OUT)
green = Pin(15, Pin.OUT)
while True:
    pressure_temp.measure()
    print('pressure:',pressure_temp.pressure_data)
    time.sleep(0.1)
    if pressure_temp.pressure_data > 1050:
        red.on()
        yellow.off()
        green.off()
    elif pressure_temp.pressure_data < 950:
        yellow.on()
        red.off()
        green.off()
    elif:
        green.on()
        red.off()
        yellow.off()