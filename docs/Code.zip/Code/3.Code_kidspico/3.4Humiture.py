'''
 * Filename    : Humiture
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
import dht

#Connect XHT11 to pin (2)
XHT = dht.DHT11(Pin(2))

# Attain temperature and humidity values every 1s and print them on Shell
while True:
    XHT.measure() # Measure values by XHT11 sensor
   # call dht built-in function to acquire temperature and humidity value and print them on Shell
    print('temperature:',XHT.temperature(),'℃','humidity:',XHT.humidity(),'%')
    time.sleep(0.5)