'''
 * Filename    : Fire alarm
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM,ADC  # Import ADC module 
import time

# Configure ADC, range of 0-3.3V
# define io26,io27,io28,io29 to ADC channel 0,1,2,3
Flame = ADC(28)  #Photores = ADC(2)
conversion_fator = 3.3 / 65535  #Voltage value of a single scale

buzzer = PWM(Pin(3))
buzzer.freq(800)

# read the analog value every 0.1s, convert it into voltage output
while True:
    Flame_value = Flame.read_u16()
    voltage = Flame_value * conversion_fator
    print('ADC Value:',Flame_value,'   Voltage:',voltage,'V')
    if voltage < 2:
        buzzer.duty_u16(5000)
    else:
        buzzer.duty_u16(0)
    time.sleep(0.1)