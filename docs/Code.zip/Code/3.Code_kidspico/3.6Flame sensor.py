'''
 * Filename    : Flame sensor
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC  # Import ADC module
import time

# Configure ADC, range of 0-3.3V
# define io26,io27,io28,io29 to ADC channel 0,1,2,3
Flame = ADC(28)  #Flame = ADC(2)
conversion_fator = 3.3 / 65535  #Voltage value of a single scale

# read the analog value every 0.1s, convert it into voltage output
while True:
    Flame_value = Flame.read_u16()
    voltage = Flame_value * conversion_fator
    print('ADC Value:',Flame_value,'   Voltage:',voltage,'V',end ='   ')
    if voltage < 2:
        print('Flame detected!')
    else:
        print(end ='\n')
    time.sleep(0.1)