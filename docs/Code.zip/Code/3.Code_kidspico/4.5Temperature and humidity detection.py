'''
 * Filename    : Temperature and humidity detection
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time
import dht

#Connect XHT11 to pin (2)
XHT = dht.DHT11(Pin(2))

red = Pin(13, Pin.OUT)
yellow = Pin(14, Pin.OUT)
green = Pin(15, Pin.OUT)

# Attain temperature and humidity value per second, and print them on Shell
while True:
    XHT.measure() # XHT11 measures values
   # Call dht built-in function to acquire temperature value, and print it on Shell
    print('temperature:',XHT.temperature())
    time.sleep(0.1)
    if XHT.temperature() > 35:
        red.on()
        yellow.off()
        green.off()
    elif XHT.temperature() > 29:
        yellow.on()
        red.off()
        green.off()
    elif XHT.temperature() > 24:
        green.on()
        red.off()
        yellow.off() 